import javax.swing.*;
import java.awt.*;

public class Ranking extends JFrame {
    public Ranking() {
        setTitle("Ranking de Jugadores");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel para mostrar los rankings
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Etiqueta de título
        JLabel titleLabel = new JLabel("Mejores Jugadores", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel);

        // Simulación de los mejores jugadores
        String[] rankings = {
            "1. PacmanMaster - 15000 puntos",
            "2. GhostHunter - 12000 puntos",
            "3. FruitCollector - 10000 puntos",
            "4. SuperPacman - 8000 puntos",
            "5. Speedster - 6000 puntos"
        };

        // Mostrar los rankings
        for (String ranking : rankings) {
            JLabel rankingLabel = new JLabel(ranking, SwingConstants.CENTER);
            rankingLabel.setFont(new Font("Arial", Font.PLAIN, 16));
            panel.add(rankingLabel);
        }

        // Botón para volver al menú
        JButton backButton = new JButton("Volver al Menú");
        backButton.addActionListener(e -> {
            Inicio ventanaInicio = new Inicio();
            ventanaInicio.setVisible(true);
            dispose(); // Cerrar la ventana de ranking
        });
        panel.add(backButton);

        // Configurar el contenido
        setContentPane(panel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Ranking ventanaRanking = new Ranking();
            ventanaRanking.setVisible(true);
        });
    }
}