import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class Juego2 extends JFrame {
    private static final long serialVersionUID = 1L;
    public static final int FILAS = 31;
    public static final int COLUMNAS = 28;
    public int tamanoCelda;
    public char[][] mapa;
    public Pacman2 pacman2;
    public ArrayList<Enemigo2> enemigos;
    public JPanel panelJuego;
    public JPanel panelInfo; 
    public Timer timer;
    public boolean juegoTerminado = false;
    private boolean invulnerable = false; 
    private JLabel labelTiempo; 
    private int vidas = 3; 
    private Image corazonImage; 
    private int tiempoTranscurrido; 
    private int tiempoTotalJuego;

    public Image muro2Image;

    public Juego2(int tiempoTranscurridoJuego1) {
        tiempoTotalJuego = tiempoTranscurridoJuego1; // Almacenar el tiempo del primer juego
        mapa = new char[FILAS][COLUMNAS];
        establecerTamanoCelda();
        generarMapa();
        inicializarInterfaz();
        enemigos = new ArrayList<>();
        crearEnemigos(25); 
        pacman2 = new Pacman2(13, 15, this); // Pasar "this" (Juego2) al constructor de Pacman2
        iniciarMovimiento();
        iniciarContadorTiempo(); 
        cargarImagenes(); 
    }


    private void establecerTamanoCelda() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenHeight = (int) (screenSize.height * 0.8);
        int screenWidth = (int) (screenSize.width * 0.8);

        int tamanoBasadoEnAltura = screenHeight / FILAS;
        int tamanoBasadoEnAncho = screenWidth / COLUMNAS;

        tamanoCelda = Math.min(tamanoBasadoEnAltura, tamanoBasadoEnAncho);
        tamanoCelda = Math.max(tamanoCelda, 15); 
    }

    private void cargarImagenes() {
        corazonImage = new ImageIcon("E:\\PacMan\\src\\Imagenes\\corazon.png").getImage(); 
        muro2Image = new ImageIcon("E:\\PacMan\\src\\Imagenes\\muro2.png").getImage(); 
    }

    private void generarMapa() {

        String[] mapaDiseno = {

            "############################",
            "#.......#..........#.......#",
            "#.#####.#.########.#.#####.#",
            "#.#####.#.########.#.#####.#",
            "#.....#.#.########.#.#.....#",
            "#####.#.#..........#.#.#####",
            "#####.....########.....#####",
            "#####.###.########.###.#####",
            "#####.###....##....###.#####",
            "#M....######.##.######....M#",
            "#####.######.##.######.#####",
            "#####..................#####",
            "#.....### ###--### ###.....#",
            "#.###.### #      # ###.###.#",
            "#.###.### #  P   # ###.###.#",
            "#.###.### #      # ###.###.#",
            "#.###.### ######## ###.###.#",
            "#.###....          ....###.#",
            "#.###.### ######## ###.###.#",
            "#.###.### ######## ###.###.#",
            "#.###.###....##....###.###.#",
            "#..........#.##.#..........#",
            "######.###.#.##.#.###.######",
            "#M.......#........#.......M#",
            "########.#.######.#.########",
            "########.#.######.#.########",
            "####...#.#...##...#.#...####",
            "#....#.....#.##.#.....#....#",
            "#.##########.##.##########.#",
            "#..........................#",
            "############################"

        };

        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                mapa[i][j] = mapaDiseno[i].charAt(j);
                if (mapa[i][j] == 'P') {
                    pacman2 = new Pacman2(j, i, null); 
                    mapa[i][j] = '.'; 
                }
            }
        }
    }

    private void inicializarInterfaz() {
        setTitle("Pacman2");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        panelJuego = new PanelJuego2(this);
        JScrollPane scrollPane = new JScrollPane(panelJuego);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);

        panelInfo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Dibujar corazones
                for (int i = 0; i < vidas; i++) {
                    g.drawImage(corazonImage, 30 + i * 50, 10, 30, 30, this);
                }
            }
        };
        panelInfo.setBackground(Color.BLACK); 
        panelInfo.setPreferredSize(new Dimension(200, FILAS * tamanoCelda)); 
        panelInfo.setLayout(new BoxLayout(panelInfo, BoxLayout.Y_AXIS)); 

        labelTiempo = new JLabel("Tiempo: 0:00");
        labelTiempo.setForeground(Color.WHITE);
        labelTiempo.setAlignmentX(Component.CENTER_ALIGNMENT); 
        panelInfo.add(Box.createVerticalStrut(50)); 
        panelInfo.add(labelTiempo); 

        add(scrollPane, BorderLayout.CENTER);
        add(panelInfo, BorderLayout.EAST); 

        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                pacman2.cambiarDireccion(e.getKeyCode()); 
            }
        });

        int width = COLUMNAS * tamanoCelda + 250; 
        int height = FILAS * tamanoCelda + 50; 
        setSize(width, height);

        setMinimumSize(new Dimension(width, height));

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void iniciarMovimiento() {
        timer = new Timer(16, e -> {
            if (!juegoTerminado) {
                pacman2.mover(mapa); 
                moverEnemigos();
                verificarColision();
                panelJuego.repaint();
                panelInfo.repaint(); 
            }
        });
        timer.start();
    }

    private void iniciarContadorTiempo() {
        Timer tiempoTimer = new Timer(1000, e -> {
            tiempoTranscurrido++; 
            tiempoTotalJuego++; // Incrementar el tiempo total del juego
            int minutos = tiempoTotalJuego / 60; 
            int segundos = tiempoTotalJuego % 60; 
            labelTiempo.setText(String.format("Tiempo: %d:%02d", minutos, segundos)); 
        });
        tiempoTimer.start(); 
    }

    private void crearEnemigos(int cantidad) {
        Random random = new Random();
        for (int i = 0; i < cantidad; i++) {
            double enemigoX, enemigoY;
            do {
                enemigoX = random.nextInt(COLUMNAS);
                enemigoY = random.nextInt(FILAS);
            } while (mapa[(int) enemigoY][(int) enemigoX] == '#' ||
                    (Math.abs(enemigoX - pacman2.getX()) < 5 && Math.abs(enemigoY - pacman2.getY()) < 5));

            enemigos.add(new Enemigo2(enemigoX, enemigoY)); 
        }
    }

    private void moverEnemigos() {
        for (Enemigo2 enemigo : enemigos) {
            enemigo.mover(mapa);
        }
    }

    private boolean todaLaComidaFueComida() {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                if (mapa[i][j] == '.') {
                    return false; 
                }
            }
        }
        return true; 
    }

    private void verificarColision() {
        for (Enemigo2 enemigo : enemigos) {
            if (Math.abs(enemigo.x - pacman2.getX()) < 0.5 && Math.abs(enemigo.y - pacman2.getY()) < 0.5) {
                if (pacman2.isSpeedBoostActive()) {
                    // Si Pacman está en velocidad activa, el enemigo es comido
                    enemigos.remove(enemigo); // Elimina al enemigo de la lista
                    break; // Salir del loop porque hemos modificado la lista de enemigos
                } else {
                    if (!invulnerable) {
                        vidas--;
                        pacman2.x = 13;
                        pacman2.y = 15;
                        if (vidas < 0) vidas = 0;

                        panelInfo.repaint();

                        if (vidas <= 0) {
                            juegoTerminado = true;
                            timer.stop();
                            JOptionPane.showMessageDialog(this, "¡Game Over!\nTiempo total: " + formatTiempo(tiempoTotalJuego), "Fin del juego", JOptionPane.INFORMATION_MESSAGE);
                            System.exit(0);
                        } else {
                            activarEscudoTemporal();
                        }
                    }
                }
            }
        }

        if (todaLaComidaFueComida()) {
            juegoTerminado = true;
            timer.stop();
            this.dispose(); // Cerrar la ventana del juego actual
            Juego3 ventanaJuego3 = new Juego3(tiempoTotalJuego); // Crear una nueva instancia de Juego3
            ventanaJuego3.setVisible(true); // Mostrar la ventana de Juego3
        }
    }


    private void activarEscudoTemporal() {
        invulnerable = true; 
        Timer escudoTimer = new Timer(2000, e -> {
            invulnerable = false; 
        });
        escudoTimer.setRepeats(false); 
        escudoTimer.start();
    }

    private String formatTiempo(int segundos) {
        int minutos = segundos / 60;
        int segundosRestantes = segundos % 60;
        return String.format("%d:%02d", minutos, segundosRestantes);
    }

    public char[][] getMapa() {
        return mapa;
    }

    public int getTamanoCelda() {
        return tamanoCelda;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Juego2(0));
    }
}