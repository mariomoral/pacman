import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class Juego2 extends JFrame {
    public static final int FILAS = 31;
    public static final int COLUMNAS = 28;
    public int tamanoCelda;
    public char[][] mapa;
    public Pacman pacman;
    public ArrayList<Enemigo> enemigos;
    public JPanel panelJuego2;
    public JPanel panelInfo;
    public Timer timer;
    public boolean juegoTerminado = false;
    private boolean invulnerable = false;
    private JLabel labelTiempo;
    private int vidas = 3;
    private int tiempoTranscurrido;
    private Image corazonImage;
    Image muro2Image;

    public Juego2(int tiempoAnterior) {
        this.tiempoTranscurrido = tiempoAnterior; // Mantener el tiempo anterior
        mapa = new char[FILAS][COLUMNAS];
        establecerTamanoCelda();
        generarMapa();
        inicializarInterfaz();
        enemigos = new ArrayList<>();
        crearEnemigos(5); // Aumentar enemigos para el segundo nivel
        iniciarMovimiento();
        iniciarContadorTiempo();
        cargarImagenes();
    }

    private void establecerTamanoCelda() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenHeight = (int)(screenSize.height * 0.8);
        int screenWidth = (int)(screenSize.width * 0.8);
        int tamanoBasadoEnAltura = screenHeight / FILAS;
        int tamanoBasadoEnAncho = screenWidth / COLUMNAS;
        tamanoCelda = Math.min(tamanoBasadoEnAltura, tamanoBasadoEnAncho);
        tamanoCelda = Math.max(tamanoCelda, 15);
    }

    private void cargarImagenes() {
        corazonImage = new ImageIcon("E:\\PacMan\\src\\Imagenes\\corazon.png").getImage();
        muro2Image = new ImageIcon("E:/PacMan/src/Imagenes/muro2.jpg").getImage();
    }

    private void generarMapa() {
        String[] mapaDiseno = {
            "############################",
            "#............##............#",
            "#.####.#####.##.#####.####.#",
            "#M####.#####.##.#####.####M#",
            "#.####.#####.##.#####.####.#",
            "#..........................#",
            "#.####.##.########.##.####.#",
            "#.####.##.########.##.####.#",
            "#......##....##....##......#",
            "######.##### ## #####.######",
            "######.##### ## #####.######",
            "######.##          ##.######",
            "######.## ###--### ##.######",
            "######.## #      # ##.######",
            "#     .   #  P   #   .     #",
            "######.## #      # ##.######",
            "######.## ######## ##.######",
            "######.##          ##.######",
            "######.## ######## ##.######",
            "######.## ######## ##.######",
            "#............##............#",
            "#.####.#####.##.#####.####.#",
            "#.####.#####.##.#####.####.#",
            "#..M##................##M..#",
            "###.##.##.########.##.##.###",
            "###.##.##.########.##.##.###",
            "#......##....##....##......#",
            "#.##########.##.##########.#",
            "#.##########.##.##########.#",
            "#..........................#",
            "############################"
        };

        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                mapa[i][j] = mapaDiseno[i].charAt(j);
                if (mapa[i][j] == 'P') {
                    pacman = new Pacman(j, i);
                    mapa[i][j] = '.';
                }
            }
        }
    }

    private void inicializarInterfaz() {
        setTitle("Pacman - Nivel 2");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        panelJuego2 = new PanelJuego2(this);
        JScrollPane scrollPane = new JScrollPane(panelJuego2);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);

        panelInfo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                for (int i = 0; i < vidas; i++) {
                    g.drawImage(corazonImage, 30 + i * 50, 10, 30, 30, this);
                }
            }
        };
        panelInfo.setBackground(Color.BLACK);
        panelInfo.setPreferredSize(new Dimension(200, FILAS * tamanoCelda));
        panelInfo.setLayout(new BoxLayout(panelInfo, BoxLayout.Y_AXIS));

        labelTiempo = new JLabel("Tiempo: 0:00");
        labelTiempo.setForeground(Color.WHITE);
        labelTiempo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelInfo.add(Box.createVerticalStrut(50));
        panelInfo.add(labelTiempo);

        add(scrollPane, BorderLayout.CENTER);
        add(panelInfo, BorderLayout.EAST);

        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                pacman.cambiarDireccion(e.getKeyCode());
            }
        });

        setSize(COLUMNAS * tamanoCelda + 250, FILAS * tamanoCelda + 50);
        setMinimumSize(new Dimension(COLUMNAS * tamanoCelda + 250, FILAS * tamanoCelda + 50));
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void iniciarMovimiento() {
        timer = new Timer(16, e -> {
            if (!juegoTerminado) {
                pacman.mover(mapa);
                moverEnemigos();
                verificarColision();
                panelJuego2.repaint();
                panelInfo.repaint();
            }
        });
        timer.start();
    }

    private void iniciarContadorTiempo() {
        Timer tiempoTimer = new Timer(1000, e -> {
            tiempoTranscurrido++; // Aumenta el tiempo
            int minutos = tiempoTranscurrido / 60;
            int segundos = tiempoTranscurrido % 60;
            labelTiempo.setText(String.format("Tiempo: %d:%02d", minutos, segundos));
        });
        tiempoTimer.start();
    }

    private void crearEnemigos(int cantidad) {
        Random random = new Random();
        for (int i = 0; i < cantidad; i++) {
            double enemigoX, enemigoY;
            do {
                enemigoX = random.nextInt(COLUMNAS);
                enemigoY = random.nextInt(FILAS);
            } while (mapa[(int)enemigoY][(int)enemigoX] == '#' || 
                     (Math.abs(enemigoX - pacman.getX()) < 5 && Math.abs(enemigoY - pacman.getY()) < 5));
            
            enemigos.add(new Enemigo(enemigoX, enemigoY));
        }
    }

    private void moverEnemigos() {
        for (Enemigo enemigo : enemigos) {
            enemigo.mover(mapa);
        }
    }

    private boolean todaLaComidaFueComida() {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                if (mapa[i][j] == '.') {
                    return false;
                }
            }
        }
        return true;
    }

    private void verificarColision() {
        for (Enemigo enemigo : enemigos) {
            if (Math.abs(enemigo.x - pacman.getX()) < 0.5 && Math.abs(enemigo.y - pacman.getY()) < 0.5) {
                if (!invulnerable) {
                    vidas--;
                    pacman.x = 13; // Restablecer posición de Pacman
                    pacman.y = 15;
                    
                    if (vidas < 0) vidas = 0;
                    panelInfo.repaint();

                    if (vidas <= 0) {
                        juegoTerminado = true;
                        timer.stop();
                        JOptionPane.showMessageDialog(this, "¡Game Over!", "Fin del juego", JOptionPane.INFORMATION_MESSAGE);
                        System.exit(0);
                    } else {
                        activarEscudoTemporal();
                    }
                }
            }
        }

        if (todaLaComidaFueComida()) {
            juegoTerminado = true;
            timer.stop();
            JOptionPane.showMessageDialog(this, "¡Ganaste el juego!", "¡Felicidades!", JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
    }

    private void activarEscudoTemporal() {
        invulnerable = true;
        Timer escudoTimer = new Timer(2000, e -> {
            invulnerable = false;
        });
        escudoTimer.setRepeats(false);
        escudoTimer.start();
    }

    public char[][] getMapa() {
        return mapa;
    }

    public int getTamanoCelda() {
        return tamanoCelda;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Juego2(0));  // Llamada inicial
    }
}
