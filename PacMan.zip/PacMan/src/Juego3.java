import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class Juego3 extends JFrame {
    public static final int FILAS = 31;
    public static final int COLUMNAS = 28;
    public int tamanoCelda;
    public char[][] mapa;
    public Pacman3 pacman3;
    public ArrayList<Enemigo3> enemigos;
    public JPanel panelJuego3;
    public JPanel panelInfo; // Panel negro para la información
    public Timer timer;
    public boolean juegoTerminado = false;
    private boolean invulnerable = false; // Estado de invulnerabilidad
    private JLabel labelTiempo; // Label para mostrar el tiempo
    private int vidas = 3; // Número de vidas
    private Image corazonImage; // Imagen del corazón
    private int tiempoTotalJuego; // Tiempo acumulado de todos los juegos
    private int tiempoActual = 0;
    public Image muroImage;
    
    public Juego3(int tiempoAcumulado) {
    	this.tiempoTotalJuego = tiempoAcumulado;
        mapa = new char[FILAS][COLUMNAS];
        establecerTamanoCelda();
        generarMapa();
        inicializarInterfaz();
        enemigos = new ArrayList<>();
        crearEnemigos(0);
        pacman3 = new Pacman3(13, 15, this);
        iniciarMovimiento();
        iniciarContadorTiempo(); // Iniciar el contador de tiempo
        cargarImagenes(); // Cargar la imagen del corazón
        actualizarLabelTiempo();
    }

    private void establecerTamanoCelda() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenHeight = (int)(screenSize.height * 0.8);
        int screenWidth = (int)(screenSize.width * 0.8);
        
        int tamanoBasadoEnAltura = screenHeight / FILAS;
        int tamanoBasadoEnAncho = screenWidth / COLUMNAS;
        
        tamanoCelda = Math.min(tamanoBasadoEnAltura, tamanoBasadoEnAncho);
        tamanoCelda = Math.max(tamanoCelda, 15); // Mínimo tamaño
    }

    private void cargarImagenes() {
        corazonImage = new ImageIcon("E:\\PacMan\\src\\Imagenes\\corazon.png").getImage();
        muroImage = new ImageIcon("E:\\PacMan\\src\\Imagenes\\murolava4.png").getImage(); // Cargar la imagen del muro
    }

    private void generarMapa() {

        String[] mapaDiseno = {


                "############################",
                "#..........#....#..........#",
                "#.########.#.##.#.########.#",
                "#M########.#.##.#.########M#",
                "#.#..........##..........#.#",
                "#...###.####.##.####.###...#",
                "###.###.####.##.####.###.###",
                "#...###.####.##.####.###...#",
                "#.#.###..............###.#.#",
                "#.#.#####.########.#####.#.#",
                "#.#.#####.########.#####.#.#",
                "#.#......          ......#.#",
                "#.#####.# ###--### #.#####.#",
                "#.......# #      # #.......#",
                "#.#.##### #  P   # #####.#.#",
                "#.#.##### #      # #####.#.#",
                "#.#.##### ######## #####.#.#",
                "#.#......          ......#.#",
                "#.#####.####.##.####.#####.#",
                "#.#####.####.##.####.#####.#",
                "#.#####.##...##...##.#####.#",
                "#.......##.######.##.......#",
                "#####.#.##.######.##.#.#####",
                "#..M..#..............#.....#",
                "#.#####.####.##.####.#####.#",
                "#.......####.##.####.......#",
                "#.#####.##...##...##.#####.#",
                "#.#####.##.######.##.#####.#",
                "#.#####.##.######.##.#####.#",
                "#.......##........##...M...#",
                "############################"

        };

        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                mapa[i][j] = mapaDiseno[i].charAt(j);
                if (mapa[i][j] == 'P') {
                    pacman3 = new Pacman3(j, i,this);
                    mapa[i][j] = '.';
                }
            }
        }
    }

    private void inicializarInterfaz() {
        setTitle("Pacman3");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        panelJuego3 = new PanelJuego3(this);
        JScrollPane scrollPane = new JScrollPane(panelJuego3);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        
        panelInfo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Dibujar corazones
                for (int i = 0; i < vidas; i++) {
                    g.drawImage(corazonImage, 30 + i * 50, 10, 30, 30, this);
                }
            }
        };
        panelInfo.setBackground(Color.BLACK); // Fondo negro
        panelInfo.setPreferredSize(new Dimension(200, FILAS * tamanoCelda)); // Ajustar tamaño del panel negro
        panelInfo.setLayout(new BoxLayout(panelInfo, BoxLayout.Y_AXIS)); // Usar BoxLayout

        labelTiempo = new JLabel("Tiempo: 0:00");
        labelTiempo.setForeground(Color.WHITE);
        labelTiempo.setAlignmentX(Component.CENTER_ALIGNMENT); // Centrar el texto
        panelInfo.add(Box.createVerticalStrut(50)); // Espaciador para separar corazones y tiempo
        panelInfo.add(labelTiempo); // Agregar el label del tiempo

        add(scrollPane, BorderLayout.CENTER);
        add(panelInfo, BorderLayout.EAST); // Agregar el panel negro a la derecha

        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                pacman3.cambiarDireccion(e.getKeyCode());
            }
        });

        // Establecer un tamaño fijo para la ventana
        int width = COLUMNAS * tamanoCelda + 250; // Aumentar ancho por el panel
        int height = FILAS * tamanoCelda + 50; // Alto con un margen
        setSize(width, height);
        
        setMinimumSize(new Dimension(width, height));
        
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void iniciarMovimiento() {
        timer = new Timer(16, e -> {
            if (!juegoTerminado) {
                pacman3.mover(mapa);
                moverEnemigos();
                verificarColision();
                panelJuego3.repaint();
                panelInfo.repaint(); // Repintar el panel de información
            }
        });
        timer.start();
    }

    private void iniciarContadorTiempo() {
        Timer tiempoTimer = new Timer(1000, e -> {
            tiempoActual++; // Incrementar el tiempo del juego actual
            tiempoTotalJuego++; // Incrementar el tiempo total acumulado
            actualizarLabelTiempo();
        });
        tiempoTimer.start();
    }
    
    private void actualizarLabelTiempo() {
        int minutos = tiempoTotalJuego / 60;
        int segundos = tiempoTotalJuego % 60;
        labelTiempo.setText(String.format("Tiempo Total: %d:%02d", minutos, segundos));
    }

    private void crearEnemigos(int cantidad) {
        Random random = new Random();
        for (int i = 0; i < cantidad; i++) {
            double enemigoX, enemigoY;
            do {
                enemigoX = random.nextInt(COLUMNAS);
                enemigoY = random.nextInt(FILAS);
            } while (mapa[(int)enemigoY][(int)enemigoX] == '#' || 
                     (Math.abs(enemigoX - pacman3.getX()) < 5 && Math.abs(enemigoY - pacman3.getY()) < 5));
            
            enemigos.add(new Enemigo3(enemigoX, enemigoY));
        }
    }

    private void moverEnemigos() {
        for (Enemigo3 enemigo : enemigos) {
            enemigo.mover(mapa);
        }
    }

    private boolean todaLaComidaFueComida() {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                if (mapa[i][j] == '.') {
                    return false; // Aún queda comida en el mapa
                }
            }
        }
        return true; // No queda más comida en el mapa
    }

    private void verificarColision() {
        for (Enemigo3 enemigo : enemigos) {
            if (Math.abs(enemigo.x - pacman3.getX()) < 0.5 && Math.abs(enemigo.y - pacman3.getY()) < 0.5) {
                if (pacman3.isSpeedBoostActive()) {
                    enemigos.remove(enemigo);
                    break;
                } else {
                    if (!invulnerable) {
                        vidas--;
                        pacman3.x = 13;
                        pacman3.y = 15;
                        if (vidas < 0) vidas = 0;
                        panelInfo.repaint();

                        if (vidas <= 0) {
                            juegoTerminado = true;
                            timer.stop();
                            JOptionPane.showMessageDialog(this, 
                                "¡Game Over!\nTiempo total: " + formatTiempo(tiempoTotalJuego), 
                                "Fin del juego", 
                                JOptionPane.INFORMATION_MESSAGE);
                            System.exit(0);
                        } else {
                            activarEscudoTemporal();
                        }
                    }
                }
            }
        }

        if (todaLaComidaFueComida()) {
            juegoTerminado = true;
            timer.stop();
            JOptionPane.showMessageDialog(this, 
                "¡Felicidades! Has completado todos los niveles.\nTiempo total: " + 
                formatTiempo(tiempoTotalJuego), 
                "Victoria", 
                JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
    }
    private String formatTiempo(int segundos) {
        int minutos = segundos / 60;
        int segundosRestantes = segundos % 60;
        return String.format("%d:%02d", minutos, segundosRestantes);
    }

    private void activarEscudoTemporal() {
        invulnerable = true; // Activa invulnerabilidad
        Timer escudoTimer = new Timer(2000, e -> {
            invulnerable = false; // Desactiva invulnerabilidad después de 2 segundos
        });
        escudoTimer.setRepeats(false); // Solo ejecutar una vez
        escudoTimer.start();
    }

    public char[][] getMapa() {
        return mapa;
    }

    public int getTamanoCelda() {
        return tamanoCelda;
    }

    public static void main(String[] args) {
    	SwingUtilities.invokeLater(() -> new Juego3(0));
    }
}