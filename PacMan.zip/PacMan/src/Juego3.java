import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Random;

public class Juego3 extends JFrame {
    public static final int FILAS = 31;
    public static final int COLUMNAS = 28;
    public int tamanoCelda;
    public char[][] mapa;
    public Pacman3 pacman3;
    public ArrayList<Enemigo3> enemigos;
    public JPanel panelJuego3;
    public JPanel panelInfo;
    public Timer timer;
    public boolean juegoTerminado = false;
    private boolean invulnerable = false;
    private JLabel labelTiempo;
    private int vidas = 3;
    private Image corazonImage;
    private int tiempoTotalJuego;
    private int tiempoActual = 0;
    public Image muroImage;
    private String jugadorNombre = "";

    public Juego3(int tiempoAcumulado) {
        this.tiempoTotalJuego = tiempoAcumulado;
        mapa = new char[FILAS][COLUMNAS];
        establecerTamanoCelda();
        generarMapa();
        inicializarInterfaz();
        enemigos = new ArrayList<>();
        crearEnemigos(25);
        pacman3 = new Pacman3(13, 15, this);
        iniciarMovimiento();
        iniciarContadorTiempo();
        cargarImagenes();
        actualizarLabelTiempo();
    }

    private void establecerTamanoCelda() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenHeight = (int)(screenSize.height * 0.9);
        int screenWidth = (int)(screenSize.width * 0.9);
        
        int tamanoBasadoEnAltura = screenHeight / FILAS;
        int tamanoBasadoEnAncho = screenWidth / COLUMNAS;
        
        tamanoCelda = Math.min(tamanoBasadoEnAltura, tamanoBasadoEnAncho);
        tamanoCelda = Math.max(tamanoCelda, 15);
    }

    private void cargarImagenes() {
        corazonImage = new ImageIcon("E:\\PacMan\\src\\Imagenes\\corazon.png").getImage();
        muroImage = new ImageIcon("E:\\PacMan\\src\\Imagenes\\lava11.jpg").getImage();
    }

    public void restarTiempo() {
        tiempoTotalJuego = Math.max(0, tiempoTotalJuego - 5);
        actualizarLabelTiempo();
    }

    private void generarMapa() {
        String[] mapaDiseno = {
                "############################",
                "#..........#....#..........#",
                "#.########.#.##.#.########.#",
                "#M########.#.##.#.########M#",
                "#.#..........##..........#.#",
                "#...###.####.##.####.###...#",
                "###.###.####.##.####.###.###",
                "#...###.####.##.####.###...#",
                "#.#.###..............###.#.#",
                "#.#.#####.########.#####.#.#",
                "#.#.#####.########.#####.#.#",
                "#.#......          ......#.#",
                "#.#####.# ###--### #.#####.#",
                "#.......# #      # #.......#",
                "#.#.##### #      # #####.#.#",
                "#.#.##### #   P  # #####.#.#",
                "#.#.##### ######## #####.#.#",
                "#.#......          ......#.#",
                "#.#####.####.##.####.#####.#",
                "#.#####.####.##.####.#####.#",
                "#.#####.##...##...##.#####.#",
                "#.......##.######.##.......#",
                "#####.#.##.######.##.#.#####",
                "#..M..#..............#.....#",
                "#.#####.####.##.####.#####.#",
                "#.......####.##.####.......#",
                "#.#####.##...##...##.#####.#",
                "#.#####.##.######.##.#####.#",
                "#.#####.##.######.##.#####.#",
                "#.......##........##...M...#",
                "############################"
        };

        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                mapa[i][j] = mapaDiseno[i].charAt(j);
                if (mapa[i][j] == 'P') {
                    pacman3 = new Pacman3(j, i, this);
                    mapa[i][j] = '.';
                }
            }
        }
    }

    private void inicializarInterfaz() {
        setTitle("Pacman3");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        panelJuego3 = new PanelJuego3(this);
        JScrollPane scrollPane = new JScrollPane(panelJuego3);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        
        panelInfo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                for (int i = 0; i < vidas; i++) {
                    g.drawImage(corazonImage, 30 + i * 50, 10, 30, 30, this);
                }
            }
        };
        panelInfo.setBackground(Color.BLACK);
        panelInfo.setPreferredSize(new Dimension(200, FILAS * tamanoCelda));
        panelInfo.setLayout(new BoxLayout(panelInfo, BoxLayout.Y_AXIS));

        labelTiempo = new JLabel("Tiempo: 0:00");
        labelTiempo.setForeground(Color.WHITE);
        labelTiempo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelInfo.add(Box.createVerticalStrut(50));
        panelInfo.add(labelTiempo);

        add(scrollPane, BorderLayout.CENTER);
        add(panelInfo, BorderLayout.EAST);

        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                pacman3.cambiarDireccion(e.getKeyCode());
            }
        });

        int width = COLUMNAS * tamanoCelda + 250;
        int height = FILAS * tamanoCelda + 50;
        setSize(width, height);
        
        setMinimumSize(new Dimension(width, height));
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void iniciarMovimiento() {
        timer = new Timer(16, e -> {
            if (!juegoTerminado) {
                pacman3.mover(mapa);
                moverEnemigos();
                verificarColision();
                panelJuego3.repaint();
                panelInfo.repaint();
            }
        });
        timer.start();
    }

    private void iniciarContadorTiempo() {
        Timer tiempoTimer = new Timer(1000, e -> {
            tiempoActual++;
            tiempoTotalJuego++;
            actualizarLabelTiempo();
        });
        tiempoTimer.start();
    }
    
    private void actualizarLabelTiempo() {
        int minutos = tiempoTotalJuego / 60;
        int segundos = tiempoTotalJuego % 60;
        labelTiempo.setText(String.format("Tiempo Total: %d:%02d", minutos, segundos));
    }

    private void crearEnemigos(int cantidad) {
        Random random = new Random();
        for (int i = 0; i < cantidad; i++) {
            double enemigoX, enemigoY;
            do {
                enemigoX = random.nextInt(COLUMNAS);
                enemigoY = random.nextInt(FILAS);
            } while (mapa[(int)enemigoY][(int)enemigoX] == '#' || 
                     (Math.abs(enemigoX - pacman3.getX()) < 5 && Math.abs(enemigoY - pacman3.getY()) < 5));
            
            enemigos.add(new Enemigo3(enemigoX, enemigoY));
        }
    }

    private void moverEnemigos() {
        for (Enemigo3 enemigo : enemigos) {
            enemigo.mover(mapa);
        }
    }

    private boolean todaLaComidaFueComida() {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                if (mapa[i][j] == '.') {
                    return false;
                }
            }
        }
        return true;
    }

    private void verificarColision() {
        for (Enemigo3 enemigo : enemigos) {
            if (Math.abs(enemigo.x - pacman3.getX()) < 0.5 && Math.abs(enemigo.y - pacman3.getY()) < 0.5) {
                if (!invulnerable) {
                    vidas--;
                    pacman3.x = 13;
                    pacman3.y = 15;
                    if (vidas < 0) vidas = 0;
                    panelInfo.repaint();

                    if (vidas <= 0) {
                        juegoTerminado = true;
                        timer.stop();
                        System.exit(0);
                    } else {
                        activarEscudoTemporal();
                    }
                }
            }
        }

        if (todaLaComidaFueComida()) {
            juegoTerminado = true;
            timer.stop();
            guardarResultado();
            System.exit(0);
        }
    }

    private void guardarResultado() {
        jugadorNombre = JOptionPane.showInputDialog(this, 
            "Has ganado!!Felicidades Introduce tu nombre:", 
            "Nombre del Jugador", 
            JOptionPane.PLAIN_MESSAGE);

        if (jugadorNombre == null || jugadorNombre.trim().isEmpty()) {
            jugadorNombre = "Jugador Anónimo";
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("E:\\PacMan\\src\\Ranking.txt", true))) {
            writer.write(jugadorNombre + " - " + formatTiempo(tiempoTotalJuego) + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String formatTiempo(int segundos) {
        int minutos = segundos / 60;
        int segundosRestantes = segundos % 60;
        return String.format("%d:%02d", minutos, segundosRestantes);
    }

    private void activarEscudoTemporal() {
        invulnerable = true;
        Timer escudoTimer = new Timer(2000, e -> {
            invulnerable = false;
        });
        escudoTimer.setRepeats(false);
        escudoTimer.start();
    }

    public char[][] getMapa() {
        return mapa;
    }

    public int getTamanoCelda() {
        return tamanoCelda;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Juego3(0));
    }
}