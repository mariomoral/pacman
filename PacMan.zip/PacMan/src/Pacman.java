import java.awt.event.KeyEvent;

class Pacman {
    public double x, y;
    public int direccionX, direccionY;
    private int lastKeyPressed = -1;
    private int keyPressCount = 0;

    public Pacman(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public void cambiarDireccion(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_UP:
                direccionX = 0;
                direccionY = -1;
                break;
            case KeyEvent.VK_DOWN:
                direccionX = 0;
                direccionY = 1;
                break;
            case KeyEvent.VK_LEFT:
                direccionX = -1;
                direccionY = 0;
                break;
            case KeyEvent.VK_RIGHT:
                direccionX = 1;
                direccionY = 0;
                break;
        }

        if (keyCode == lastKeyPressed) {
            keyPressCount++;
        } else {
            keyPressCount = 1;
        }
        lastKeyPressed = keyCode;
    }

    public void mover(char[][] mapa) {
        double velocidad = 0.15;
        double newX = x + direccionX * velocidad;
        double newY = y + direccionY * velocidad;

        // Asegúrate de que newX y newY estén dentro de los límites del mapa
        if (newX >= 0 && newX < Juego.COLUMNAS && newY >= 0 && newY < Juego.FILAS &&
            mapa[(int)Math.round(newY)][(int)Math.round(newX)] != '#') {
            x = newX;
            y = newY;
            if (mapa[(int)Math.round(y)][(int)Math.round(x)] == '.') {
                mapa[(int)Math.round(y)][(int)Math.round(x)] = ' ';
            }
        }
    }


    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}
