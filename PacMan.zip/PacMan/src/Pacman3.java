import javax.swing.*;
import java.awt.event.KeyEvent;

class Pacman3 {
    public double x, y;
    public int direccionX, direccionY;
    private int lastKeyPressed = -1;
    private int keyPressCount = 0;
    private boolean speedBoostActive = false;
    private Timer speedBoostTimer;
    private double baseSpeed = 0.15;
    private double currentSpeed = baseSpeed;

    // Cargar los GIFs
    private ImageIcon pacmanUp;
    private ImageIcon pacmanDown;
    private ImageIcon pacmanLeft;
    private ImageIcon pacmanRight;

    public Pacman3(double x, double y, Juego3 juego) {
        this.x = x;
        this.y = y;
        cargarImagenes();
        initializeSpeedBoostTimer();
    }

    private void initializeSpeedBoostTimer() {
        speedBoostTimer = new Timer(10000000, e -> {
            speedBoostActive = false;
            currentSpeed = baseSpeed;
            speedBoostTimer.stop();
        });
        speedBoostTimer.setRepeats(false);
    }

    private void cargarImagenes() {
        pacmanUp = new ImageIcon("E:\\PacMan\\src\\Imagenes\\nave-arr.gif");
        pacmanDown = new ImageIcon("E:\\PacMan\\src\\Imagenes\\nave-aba.gif");
        pacmanLeft = new ImageIcon("E:\\PacMan\\src\\Imagenes\\pacman-izq.gif");
        pacmanRight = new ImageIcon("E:\\PacMan\\src\\Imagenes\\pacman-der.gif");
    }

    public void cambiarDireccion(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_UP:
                direccionX = 0;
                direccionY = -1;
                break;
            case KeyEvent.VK_DOWN:
                direccionX = 0;
                direccionY = 1;
                break;
            case KeyEvent.VK_LEFT:
                direccionX = -1;
                direccionY = 0;
                break;
            case KeyEvent.VK_RIGHT:
                direccionX = 1;
                direccionY = 0;
                break;
        }

        if (keyCode == lastKeyPressed) {
            keyPressCount++;
        } else {
            keyPressCount = 1;
        }
        lastKeyPressed = keyCode;
    }

    public void activateSpeedBoost() {
        speedBoostActive = true;
        currentSpeed = baseSpeed * 1.5; // 50% más rápido
        if (speedBoostTimer.isRunning()) {
            speedBoostTimer.restart();
        } else {
            speedBoostTimer.start();
        }
    }

    public void mover(char[][] mapa) {
        double newX = x + direccionX * currentSpeed;
        double newY = y + direccionY * currentSpeed;

        // Verificar límites del mapa y colisiones
        if (newX >= 0 && newX < Juego.COLUMNAS && newY >= 0 && newY < Juego.FILAS) {
            int roundedY = (int)Math.round(newY);
            int roundedX = (int)Math.round(newX);
            
            if (mapa[roundedY][roundedX] != '#') {
                x = newX;
                y = newY;
                
                // Verificar si hay power-up de velocidad
                if (mapa[roundedY][roundedX] == 'M') {
                    mapa[roundedY][roundedX] = ' '; // Eliminar el power-up del mapa
                    activateSpeedBoost();
                }
                // Recolectar puntos normales
                else if (mapa[roundedY][roundedX] == '.') {
                    mapa[roundedY][roundedX] = ' ';
                }
            }
        }
    }
    
    public boolean isSpeedBoostActive() {
        return speedBoostActive;
    }

    public void deactivateSpeedBoost() {
        speedBoostActive = false;
        currentSpeed = baseSpeed; // Restablecer la velocidad base
        if (speedBoostTimer.isRunning()) {
            speedBoostTimer.stop(); // Detener el temporizador de speed boost si está corriendo
        }
    }

    public ImageIcon getIcono() {
        if (direccionY < 0) {
            return pacmanUp;
        } else if (direccionY > 0) {
            return pacmanDown;
        } else if (direccionX < 0) {
            return pacmanLeft;
        } else if (direccionX > 0) {
            return pacmanRight;
        }
        return pacmanRight; // Por defecto
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}