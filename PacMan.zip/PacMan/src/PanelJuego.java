import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
class PanelJuego extends JPanel {
    private Juego juego;
    private ImageIcon enemigoIcon;

    public PanelJuego(Juego juego) {
        this.juego = juego;
        setBackground(Color.BLACK);
        cargarImagenEnemigo();
    }

    private void cargarImagenEnemigo() {
        try {
            enemigoIcon = new ImageIcon("E:\\PacMan\\src\\Imagenes\\amarillo-aba.gif"); // Cargar la imagen del enemigo
        } catch (Exception e) {
            e.printStackTrace();
            enemigoIcon = null; // Si falla, asigna null
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        dibujarJuego(g);
    }

    private void dibujarJuego(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int offsetX = (getWidth() - (Juego.COLUMNAS * juego.getTamanoCelda())) / 2;
        int offsetY = (getHeight() - (Juego.FILAS * juego.getTamanoCelda())) / 2;

        // Dibujar el mapa y Pacman
        for (int i = 0; i < Juego.FILAS; i++) {
            for (int j = 0; j < Juego.COLUMNAS; j++) {
                int x = offsetX + j * juego.getTamanoCelda();
                int y = offsetY + i * juego.getTamanoCelda();
                if (juego.getMapa()[i][j] == '#') {
                    // Dibujar la imagen del muro en lugar de un rectángulo de color
                    g2d.drawImage(juego.muroImage, x, y, juego.getTamanoCelda(), juego.getTamanoCelda(), this);
                } else if (juego.getMapa()[i][j] == '.') {
                    g2d.setColor(Color.YELLOW);
                    int puntoDiametro = Math.max(juego.getTamanoCelda() / 4, 3);
                    g2d.fillOval(x + (juego.getTamanoCelda() - puntoDiametro) / 2,
                                 y + (juego.getTamanoCelda() - puntoDiametro) / 2,
                                 puntoDiametro, puntoDiametro);
                }
            }
        }

        // Dibuja Pacman
        ImageIcon pacmanIcon = juego.pacman.getIcono();
        g2d.drawImage(pacmanIcon.getImage(),
                      offsetX + (int)(juego.pacman.getX() * juego.getTamanoCelda()),
                      offsetY + (int)(juego.pacman.getY() * juego.getTamanoCelda()),
                      juego.getTamanoCelda(), juego.getTamanoCelda(),
                      this);

        // Dibuja enemigos
        for (Enemigo enemigo : juego.enemigos) {
            g2d.drawImage(enemigo.getIcono().getImage(),
                          offsetX + (int)(enemigo.x * juego.getTamanoCelda()),
                          offsetY + (int)(enemigo.y * juego.getTamanoCelda()),
                          juego.getTamanoCelda(), juego.getTamanoCelda(),
                          this);
        }
    }
}