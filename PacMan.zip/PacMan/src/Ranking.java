import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;
import java.util.ArrayList;

public class Ranking extends JFrame {

    public Ranking() {
        setTitle("Ranking de Jugadores");
        setSize(845, 720);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel para mostrar los rankings
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Establecer el fondo negro para el panel
        panel.setBackground(Color.BLACK);

        // Etiqueta de título, con texto blanco y centrado
        JLabel titleLabel = new JLabel("Mejores Jugadores", SwingConstants.CENTER);
        titleLabel.setFont(cargarFuente("E:\\PacMan\\src\\PressStart2P.ttf", 20)); // Cargar la fuente personalizada
        titleLabel.setForeground(Color.WHITE); // Cambiar color de texto a blanco
        panel.add(titleLabel);

        // Cargar los jugadores desde el archivo
        List<String> rankings = cargarRankings();

        // Mostrar los rankings
        if (rankings.isEmpty()) {
            panel.add(new JLabel("No se encontraron rankings.", SwingConstants.CENTER));
        } else {
            for (String ranking : rankings) {
                JLabel rankingLabel = new JLabel(ranking, SwingConstants.CENTER);
                rankingLabel.setForeground(Color.WHITE); // Cambiar color de texto a blanco
                panel.add(rankingLabel);
            }
        }

        // Botón para volver al menú
        JButton backButton = new JButton("Volver al Menú");
        backButton.setBackground(Color.GRAY); // Establecer color de fondo del botón
        backButton.setForeground(Color.WHITE); // Establecer color del texto del botón
        backButton.addActionListener(e -> {
            Inicio ventanaInicio = new Inicio();
            ventanaInicio.setVisible(true);
            dispose(); // Cerrar la ventana de ranking
        });
        panel.add(backButton);

        // Configurar el contenido
        setContentPane(panel);
    }

    // Método para cargar la fuente personalizada
    private Font cargarFuente(String rutaFuente, float tamano) {
        try {
            Font fuente = Font.createFont(Font.TRUETYPE_FONT, new File(rutaFuente));
            return fuente.deriveFont(tamano); // Aplicar el tamaño de la fuente
        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
            // Si no se puede cargar la fuente, se utiliza la fuente por defecto
            return new Font("Arial", Font.BOLD, (int) tamano);
        }
    }

    // Método para cargar los rankings desde un archivo .txt
    private List<String> cargarRankings() {
        List<String> rankings = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("E:\\PacMan\\src\\Ranking.txt"))) {
            String line;
            List<Player> players = new ArrayList<>();

            // Leer el archivo línea por línea
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(" - "); // Separar el nombre del jugador y el tiempo
                if (parts.length == 2) {
                    String nombreJugador = parts[0].trim();
                    String tiempoStr = parts[1].trim();
                    int tiempoTotal = parseTiempo(tiempoStr); // Convertir el tiempo a segundos
                    players.add(new Player(nombreJugador, tiempoTotal));
                }
            }

            // Ordenar los jugadores por tiempo total (de menor a mayor tiempo)
            players.sort(Comparator.comparingInt(Player::getTiempoTotal));

            // Formatear los jugadores ordenados en una lista
            int rank = 1;
            for (Player player : players) {
                rankings.add(player.getNombreJugador() + " - " + formatTiempo(player.getTiempoTotal()));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return rankings;
    }

    // Método para convertir el tiempo en formato mm:ss a segundos
    private int parseTiempo(String tiempoStr) {
        String[] partes = tiempoStr.split(":");
        int minutos = Integer.parseInt(partes[0].trim());
        int segundos = Integer.parseInt(partes[1].trim());
        return minutos * 60 + segundos;
    }

    // Método para formatear el tiempo en segundos a mm:ss
    private String formatTiempo(int segundos) {
        int minutos = segundos / 60;
        int segsRestantes = segundos % 60;
        return String.format("%d:%02d", minutos, segsRestantes);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Ranking ventanaRanking = new Ranking();
            ventanaRanking.setVisible(true);
        });
    }

    // Clase interna para representar un jugador
    static class Player {
        private String nombreJugador;
        private int tiempoTotal;

        public Player(String nombreJugador, int tiempoTotal) {
            this.nombreJugador = nombreJugador;
            this.tiempoTotal = tiempoTotal;
        }

        public String getNombreJugador() {
            return nombreJugador;
        }

        public int getTiempoTotal() {
            return tiempoTotal;
        }
    }
}
